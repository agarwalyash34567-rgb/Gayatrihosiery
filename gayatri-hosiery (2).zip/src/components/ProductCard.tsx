import React from 'react';
import { Heart, ShoppingCart, Eye } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  key?: string;
  product: Product;
  onSelect: (p: Product) => void;
  isWishlisted: boolean;
  onToggleWishlist: (p: Product) => void;
  onAddToCart: (p: Product, size: string, qty?: number) => void;
}

export default function ProductCard({
  product,
  onSelect,
  isWishlisted,
  onToggleWishlist,
  onAddToCart,
}: ProductCardProps) {
  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    // Add first available size as default
    const defaultSize = product.sizes[0] || 'M';
    onAddToCart(product, defaultSize);
  };

  return (
    <div
      onClick={() => onSelect(product)}
      className="group bg-surface border border-surface-container-highest rounded-xl overflow-hidden cursor-pointer transition-all duration-300 hover:shadow-xl hover:border-gold/40 flex flex-col h-full"
    >
      {/* Product Image Section */}
      <div className="relative aspect-[4/5] overflow-hidden bg-surface-container-low">
        
        {/* Hover Zoom & Scale Effect */}
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover object-center transform group-hover:scale-105 transition-transform duration-500"
          referrerPolicy="no-referrer"
          loading="lazy"
        />

        {/* Floating Badges */}
        {product.badge && (
          <span className="absolute top-3 left-3 bg-navy text-surface text-[8px] font-bold uppercase tracking-widest px-2.5 py-1 rounded">
            {product.badge}
          </span>
        )}

        {/* Favorite Icon Toggle */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product);
          }}
          className={`absolute top-3 right-3 p-2 rounded-full shadow-md backdrop-blur-md transition-all duration-300 border focus:outline-none ${
            isWishlisted
              ? 'bg-gold border-gold text-surface'
              : 'bg-surface/80 border-surface-container-highest text-on-surface hover:bg-gold hover:text-surface hover:border-gold'
          }`}
          aria-label="Add to Wishlist"
        >
          <Heart size={14} fill={isWishlisted ? 'currentColor' : 'none'} className="transition-transform active:scale-12s" />
        </button>

        {/* Image Hover Button Bar overlay */}
        <div className="absolute inset-0 bg-navy/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center space-x-3">
          <button
            onClick={() => onSelect(product)}
            className="p-3 bg-surface text-navy rounded-full shadow-lg hover:bg-gold hover:text-surface transition-all transform translate-y-4 group-hover:translate-y-0 duration-300"
            title="View Details"
          >
            <Eye size={16} />
          </button>
          
          <button
            onClick={handleQuickAdd}
            className="p-3 bg-surface text-navy rounded-full shadow-lg hover:bg-gold hover:text-surface transition-all transform translate-y-4 group-hover:translate-y-0 duration-300 delay-75"
            title="Quick Add to Cart"
          >
            <ShoppingCart size={16} />
          </button>
        </div>
      </div>

      {/* Product Text Details Section */}
      <div className="p-4 flex-grow flex flex-col justify-between">
        <div className="space-y-1">
          <div className="flex items-center justify-between">
            <span className="font-sans text-[9px] font-bold text-gold uppercase tracking-widest">
              {product.category === 'accessories' ? 'Socks' : `${product.category}'s wear`}
            </span>
            <span className="font-sans text-[9px] text-on-surface-variant/80 font-medium bg-surface-container px-1.5 py-0.5 rounded">
              {product.fabric}
            </span>
          </div>

          <h3 className="font-serif text-sm font-semibold text-navy group-hover:text-gold transition-colors line-clamp-1">
            {product.name}
          </h3>
          
          <p className="font-sans text-[11px] text-on-surface-variant line-clamp-2">
            {product.description}
          </p>
        </div>

        {/* Pricing and CTA bar */}
        <div className="flex items-center justify-between pt-3 mt-2 border-t border-surface-container">
          <div>
            <p className="font-sans text-xs text-on-surface-variant/60 font-semibold line-through">
              ₹{Math.round(product.price * 1.2)}
            </p>
            <p className="font-sans text-sm font-bold text-navy">
              ₹{product.price.toLocaleString('en-IN')}
            </p>
          </div>
          
          <button
            onClick={handleQuickAdd}
            className="font-sans text-[9px] font-bold tracking-widest text-navy group-hover:text-gold group-hover:underline uppercase transition-all"
          >
            QUICK ADD +
          </button>
        </div>
      </div>
    </div>
  );
}
