import React, { useState } from 'react';
import { Search, ShoppingBag, Heart, Menu, X, ChevronRight } from 'lucide-react';
import { ScreenType, CartItem, Product } from '../types';

interface HeaderProps {
  currentScreen: ScreenType;
  setScreen: (screen: ScreenType) => void;
  cart: CartItem[];
  setIsCartOpen: (open: boolean) => void;
  wishlist: Product[];
  setIsWishlistOpen: (open: boolean) => void;
  onSearch: (query: string) => void;
  setSelectedProduct: (p: Product) => void;
  allProducts: Product[];
}

export default function Header({
  currentScreen,
  setScreen,
  cart,
  setIsCartOpen,
  wishlist,
  setIsWishlistOpen,
  onSearch,
  setSelectedProduct,
  allProducts,
}: HeaderProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchActive, setIsSearchActive] = useState(false);

  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const navItems: { label: string; value: ScreenType }[] = [
    { label: 'WOMEN', value: 'women' },
    { label: 'MEN', value: 'men' },
    { label: 'KIDS', value: 'kids' },
    { label: 'NEW ARRIVALS', value: 'new-arrivals' },
    { label: 'ABOUT US', value: 'about-us' },
    { label: 'CONTACT US', value: 'contact' },
  ];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onSearch(searchQuery);
      // Find matching page if exact or category matches
      const lower = searchQuery.toLowerCase();
      if (lower.includes('women')) setScreen('women');
      else if (lower.includes('men')) setScreen('men');
      else if (lower.includes('kid')) setScreen('kids');
      else if (lower.includes('new')) setScreen('new-arrivals');
      else {
        // Go to new-arrivals or filter current view
        setScreen('new-arrivals');
      }
    }
  };

  const filteredSearchSuggestions = searchQuery
    ? allProducts.filter((p) => p.name.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, 5)
    : [];

  return (
    <header className="relative w-full z-40 bg-surface text-on-surface border-b border-surface-container-highest">
      {/* Top Bar Announcement */}
      <div className="w-full bg-navy text-surface py-2 px-4 text-center text-xs tracking-widest font-sans font-semibold">
        FREE STANDARD SHIPPING ACROSS INDIA
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
        {/* Mobile Navigation Trigger */}
        <div className="flex md:hidden">
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="text-on-surface hover:text-gold transition-colors focus:outline-none"
            aria-label="Toggle Menu"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Brand/Logo */}
        <div className="flex flex-col items-center md:items-start text-center md:text-left">
          <button
            onClick={() => {
              setScreen('home');
              setIsMobileMenuOpen(false);
            }}
            className="focus:outline-none group"
          >
            <h1 className="font-serif text-xl sm:text-2xl font-bold tracking-widest text-primary group-hover:text-gold transition-colors">
              GAYATRI HOSIERY
            </h1>
            <p className="font-sans text-[9px] tracking-[0.25em] text-on-surface-variant font-medium mt-0.5">
              PREMIUM COMFORT & DIRECT WEAVER VALUES
            </p>
          </button>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center space-x-8 font-sans text-xs font-semibold tracking-widest">
          {navItems.map((item) => (
            <button
              key={item.value}
              onClick={() => {
                setScreen(item.value);
                onSearch('');
                setSearchQuery('');
              }}
              className={`transition-colors relative py-2 hover:text-gold focus:outline-none ${
                currentScreen === item.value ? 'text-gold' : 'text-on-surface'
              }`}
            >
              {item.label}
              {currentScreen === item.value && (
                <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-gold rounded-full" />
              )}
            </button>
          ))}
        </nav>

        {/* Action Controls */}
        <div className="flex items-center space-x-4">
          {/* Desktop Search Toggle */}
          <div className="relative">
            <button
              onClick={() => setIsSearchActive(!isSearchActive)}
              className="p-1 text-on-surface hover:text-gold transition-colors focus:outline-none"
              aria-label="Search Catalog"
            >
              <Search size={20} />
            </button>
            
            {isSearchActive && (
              <div className="absolute right-0 mt-3 bg-surface border border-surface-container-highest shadow-xl rounded-lg p-3 w-72 z-50">
                <form onSubmit={handleSearchSubmit} className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => {
                      setSearchQuery(e.target.value);
                      onSearch(e.target.value);
                    }}
                    placeholder="Search socks, innerwear..."
                    className="w-full bg-surface-container-low text-xs p-2 rounded border border-surface-container focus:border-gold outline-none font-sans"
                    autoFocus
                  />
                  <button type="submit" className="bg-navy text-surface p-2 rounded hover:bg-gold transition-colors">
                    <Search size={14} />
                  </button>
                </form>

                {/* Suggestions dropdown */}
                {filteredSearchSuggestions.length > 0 && (
                  <div className="mt-2 border-t border-surface-container-highest pt-2 max-h-48 overflow-y-auto custom-scrollbar">
                    <p className="text-[10px] uppercase tracking-wider text-on-surface-variant font-bold mb-1 px-1">
                      Suggested Products
                    </p>
                    {filteredSearchSuggestions.map((prod) => (
                      <button
                        key={prod.id}
                        onClick={() => {
                          setSelectedProduct(prod);
                          setScreen('product-detail');
                          setIsSearchActive(false);
                          setSearchQuery('');
                        }}
                        className="w-full flex items-center space-x-2 p-1 hover:bg-surface-container-low rounded text-left transition-colors"
                      >
                        <img src={prod.image} alt={prod.name} className="w-8 h-8 object-cover rounded" />
                        <div className="overflow-hidden">
                          <p className="text-xs font-semibold text-on-surface truncate">{prod.name}</p>
                          <p className="text-[10px] text-gold font-medium">₹{prod.price}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Wishlist Button */}
          <button
            onClick={() => setIsWishlistOpen(true)}
            className="p-1 text-on-surface hover:text-gold transition-colors relative focus:outline-none"
            aria-label="Wishlist"
          >
            <Heart size={20} />
            {wishlist.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-gold text-surface text-[9px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                {wishlist.length}
              </span>
            )}
          </button>

          {/* Cart Button */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="p-1 text-on-surface hover:text-gold transition-colors relative focus:outline-none"
            aria-label="Shopping Cart"
          >
            <ShoppingBag size={20} />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-navy text-surface text-[9px] w-4 h-4 rounded-full flex items-center justify-center font-bold border border-surface">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 top-[112px] bg-black/40 z-30 transition-opacity" onClick={() => setIsMobileMenuOpen(false)}>
          <div
            className="w-4/5 max-w-sm bg-surface h-full shadow-2xl p-6 flex flex-col justify-between"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-surface-container-highest">
                <span className="font-serif text-sm font-semibold tracking-wider text-on-surface-variant">
                  Shop Navigation
                </span>
                <button onClick={() => setIsMobileMenuOpen(false)} className="text-on-surface-variant hover:text-gold">
                  <X size={20} />
                </button>
              </div>

              {/* Navigation Links list */}
              <nav className="flex flex-col space-y-4">
                {navItems.map((item) => (
                  <button
                    key={item.value}
                    onClick={() => {
                      setScreen(item.value);
                      setIsMobileMenuOpen(false);
                      onSearch('');
                      setSearchQuery('');
                    }}
                    className={`flex items-center justify-between text-sm font-bold tracking-widest text-left py-2 hover:text-gold transition-colors ${
                      currentScreen === item.value ? 'text-gold' : 'text-on-surface'
                    }`}
                  >
                    <span>{item.label}</span>
                    <ChevronRight size={16} className="text-on-surface-variant" />
                  </button>
                ))}
              </nav>
            </div>

            <div className="border-t border-surface-container-highest pt-6 mt-auto">
              <div className="flex items-center space-x-3 mb-4">
                <span className="material-symbols-outlined text-gold">verified_user</span>
                <p className="text-xs text-on-surface-variant font-medium">100% Quality & Indian Heritage Guaranteed</p>
              </div>
              <p className="text-[10px] text-on-surface-variant/70 text-center">
                Gayatri Hosiery © {new Date().getFullYear()}
              </p>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
