import React from 'react';
import { ArrowRight, Sparkles, Award, ShieldCheck } from 'lucide-react';
import { ScreenType } from '../types';

interface HeroSectionProps {
  setScreen: (screen: ScreenType) => void;
}

export default function HeroSection({ setScreen }: HeroSectionProps) {
  return (
    <section className="relative bg-[#fff8f5] py-16 md:py-24 overflow-hidden">
      {/* Background Subtle Watermark */}
      <div className="absolute inset-0 watermark-pattern opacity-[0.02] pointer-events-none" />

      {/* Background gold spotlight */}
      <div className="absolute -left-48 top-12 w-96 h-96 rounded-full bg-gold/5 blur-3xl pointer-events-none" />
      <div className="absolute -right-48 bottom-12 w-96 h-96 rounded-full bg-navy/5 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Editorial Content Column */}
          <div className="lg:col-span-7 space-y-6 md:space-y-8 animate-fade-in">
            <div className="inline-flex items-center space-x-2 bg-gold/10 border border-gold/20 px-3.5 py-1.5 rounded-full">
              <Sparkles size={14} className="text-gold" />
              <span className="font-sans text-[10px] tracking-widest font-bold text-gold uppercase">
                Direct Weaver Values • Authentic Luxury
              </span>
            </div>

            <div className="space-y-3">
              <h2 className="font-serif text-3xl sm:text-5xl lg:text-6xl font-medium text-navy tracking-tight leading-tight">
                Crafting Comfort <br />
                <span className="font-serif italic font-normal text-gold">For Generations.</span>
              </h2>
              <p className="font-sans text-[10px] sm:text-xs tracking-[0.3em] text-on-surface-variant font-semibold uppercase">
                Premium Comfort & Direct Weaver Values
              </p>
            </div>

            <p className="font-sans text-xs sm:text-sm text-on-surface-variant leading-relaxed max-w-xl">
              Experience the pinnacle of comfort with our Premium Luxe collection. Crafted from high-density, long-staple pima cotton, these pieces offer a secondary-skin feel with unparalleled breathability and a subtle, sophisticated sheen. Designed and perfected in India.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-2">
              <button
                onClick={() => setScreen('new-arrivals')}
                className="group flex items-center justify-center space-x-2 bg-navy text-surface py-3.5 px-8 text-xs font-bold tracking-widest rounded-lg shadow-lg hover:bg-gold transition-all duration-300"
              >
                <span>EXPLORE OUR COLLECTIONS</span>
                <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </button>
              
              <button
                onClick={() => setScreen('about-us')}
                className="flex items-center justify-center space-x-2 border border-navy text-navy py-3.5 px-8 text-xs font-bold tracking-widest rounded-lg hover:bg-navy/5 transition-all"
              >
                <span>OUR STORY</span>
              </button>
            </div>

            {/* Trust Factors Badge Group */}
            <div className="grid grid-cols-3 gap-4 border-t border-surface-container-highest pt-8 max-w-lg">
              <div className="flex items-center space-x-2">
                <div className="p-2 bg-gold/10 rounded-lg text-gold">
                  <Award size={16} />
                </div>
                <div>
                  <h4 className="font-serif text-[11px] font-bold text-navy">Pure Cotton</h4>
                  <p className="font-sans text-[9px] text-on-surface-variant">Long-staple fibers</p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <div className="p-2 bg-gold/10 rounded-lg text-gold">
                  <Sparkles size={16} />
                </div>
                <div>
                  <h4 className="font-serif text-[11px] font-bold text-navy">Pima Cotton</h4>
                  <p className="font-sans text-[9px] text-on-surface-variant">Ultra-soft blend</p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <div className="p-2 bg-gold/10 rounded-lg text-gold">
                  <ShieldCheck size={16} />
                </div>
                <div>
                  <h4 className="font-serif text-[11px] font-bold text-navy">Perfect Fit</h4>
                  <p className="font-sans text-[9px] text-on-surface-variant">No marks guarantee</p>
                </div>
              </div>
            </div>
          </div>

          {/* Aesthetic Showcase Image Column */}
          <div className="lg:col-span-5 relative flex justify-center lg:justify-end">
            <div className="relative w-full max-w-sm sm:max-w-md aspect-[4/5] rounded-2xl overflow-hidden shadow-2xl border-4 border-white">
              {/* Image Frame */}
              <img
                src="https://lh3.googleusercontent.com/aida/AP1WRLtPBR6Hb2OPIJyAc0i9RBL8Bc0PtymbcmB_EIFNfCqwxTw1jNs9h_W-3lZXYtsd6OcWfjZErBaGy4XIG23qoZ-7k2_7IfriBDwPHcP_vjQ9S3m1M5gKnEwU2_7Ev5Zq_zkMaqHjNaAyg_NSqu_OFeKUNdBvUYqpJgQiDg6cHrccrtDVVZShLh6H5V0YELWih4J667Yn5a1clXeqVhrcOSRaX-fYWoX1RtNftQ3S3VS6hU1xzc8yhAQ-RJo"
                alt="Premium Luxury Knitwear model"
                className="w-full h-full object-cover object-center transform hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              
              {/* Blur accent tag overlay */}
              <div className="absolute bottom-6 left-6 right-6 bg-surface/90 backdrop-blur-md p-4 rounded-xl border border-white/20 flex justify-between items-center shadow-lg">
                <div>
                  <p className="font-sans text-[9px] tracking-widest text-gold font-bold uppercase">HOT PRODUCT</p>
                  <h3 className="font-serif text-sm font-semibold text-navy mt-0.5">Premium Luxe Silk-Finish</h3>
                </div>
                <button
                  onClick={() => {
                    setScreen('new-arrivals');
                  }}
                  className="bg-navy text-surface p-2 rounded-full hover:bg-gold hover:text-navy transition-all"
                >
                  <ArrowRight size={16} />
                </button>
              </div>
            </div>

            {/* Overlapping small detail bubble to show quality */}
            <div className="hidden sm:block absolute -left-8 bottom-12 bg-[#000613] text-surface p-4 rounded-xl border border-gold/40 shadow-xl max-w-[160px] animate-bounce" style={{ animationDuration: '4s' }}>
              <div className="flex items-center space-x-1.5 mb-1 text-gold">
                <Sparkles size={14} />
                <span className="font-sans text-[8px] tracking-widest font-bold">FEEL THE DIFFERENCE</span>
              </div>
              <p className="font-sans text-[10px] text-surface-container/80 leading-normal">
                Sourced from boutique organic cotton farms.
              </p>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
